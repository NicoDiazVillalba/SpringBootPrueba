package com.miempresa.holamundo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolamundoApplicationTests {

	@Test
	void contextLoads() {
	}

}
